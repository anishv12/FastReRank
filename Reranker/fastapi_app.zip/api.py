from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from reranker import HybridReranker  # Import your HybridReranker class

# Initialize FastAPI app
app = FastAPI()

# Initialize the HybridReranker
reranker = HybridReranker()

# Request model for input validation
class RerankRequest(BaseModel):
    query: str
    candidates: list[str]
    top_n: int = 3  # Optional; defaults to 3

# Response model
class RerankResponse(BaseModel):
    ranked_candidates: list[str]

# Define an endpoint for reranking
@app.post("/rerank", response_model=RerankResponse)
async def rerank(request: RerankRequest):
    """
    Rerank endpoint for the HybridReranker.
    """
    try:
        ranked_candidates = reranker.rerank(
            query=request.query,
            candidates=request.candidates
        )[:request.top_n]
        return {"ranked_candidates": ranked_candidates}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
